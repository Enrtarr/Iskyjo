package game.actions;

import game.*;

public class DrawCardAction implements Action {
    private final Pile pile;

    public DrawCardAction(Pile pile) {
        this.pile = pile;
    }

    @Override
    public void execute(GameController game) {
        game.drawCard(this.pile);
    }
}
