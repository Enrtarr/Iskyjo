package game;

import java.util.ArrayList;

import game.actions.Action;

public class GameController {

    private ArrayList<Player> players;
    private Pile drawPile;
    private Pile discardPile;
    private int currentPlayerIndex;
    private int startingPlayerIndex;
    private int round;
    private boolean isRoundEnding;
    private int roundScore;

    public GameController(ArrayList<Player> players, int nbrOfCards) {
        this.players = players;
        this.drawPile = new Pile(nbrOfCards);
        this.discardPile = new Pile(0);
        this.currentPlayerIndex = 0;
        this.startingPlayerIndex = 0;
        this.round = 1;
        this.isRoundEnding = true;
        this.roundScore = 50;
    }

    public void execute(Action action) {
        action.execute(this);
    }

    public Player getCurrentPlayer() {
        return this.players.get(this.currentPlayerIndex);
    }

    public Card getDrawPileTop() {
        if (this.drawPile.getAllCards().size() > 0) {
            return this.drawPile.getAllCards().getLast();
        }
        else {
            throw (new IllegalStateException("The draw pile is empty"));
        }
    }

        public Card getDiscardPileTop() {
        if (this.discardPile.getAllCards().size() > 0) {
            return this.discardPile.getAllCards().getLast();
        }
        else {
            throw (new IllegalStateException("The discard pile is empty"));
        }
    }

    public Card[] getBothPilesTop() {
        return new Card[] {this.drawPile.getAllCards().getLast(), this.discardPile.getAllCards().getLast()};
    }

    public void flipCard(Player player, int[] cardCoords) {
        if (player != this.getCurrentPlayer()) {
            throw (new IllegalStateException("Not your turn"));
        }

        player.getDeck().flipCard(cardCoords);
    }

    public void replaceCard(Player player, int[] cardCoords, Card newCard) {
        if (player != this.getCurrentPlayer()) {
            throw (new IllegalStateException("Not your turn"));
        }

        // AJOUTER DES CHECKS DE PRÉSENCE DANS LA PILE

        Card oldCard = player.getDeck().replaceCard(cardCoords, newCard);
        this.discardCard(player, oldCard);

        this.endTurn();
    }

    public Card drawCard(Pile pile) {
        return pile.pop();
    }

    public void discardCard(Player player, Card card) {
        if (player != this.getCurrentPlayer()) {
            throw (new IllegalStateException("Not your turn"));
        }

        this.discardPile.addCard(card);

        // We'll assume the card was already removed from the pile
        // so we don't try to remove duplicates

        this.endTurn();
    }

    private void endTurn() {
        if (!this.getCurrentPlayer().getDeck().hasHiddenCard()) {
            this.endRound();
        }

        this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.size();

        // Check if the current player has reached the point quota, if yes, endRound()

        if (this.startingPlayerIndex == this.currentPlayerIndex && this.isRoundEnding) {
            // do something, but I don't know what yet
            this.prepareNewRound();
        }
        
    }

    private void beginRound() {
        this.isRoundEnding = false;
    }

    private void endRound() {
        this.round = this.round + 1;
        this.isRoundEnding = true;
    }

    private void prepareNewRound() {
        if (!this.isRoundEnding) {
            throw (new IllegalStateException("Round isn't ending yet"));
        }

        System.out.println("Preparing new round...");

        for (Player plr : this.players) {
            // AJOUTER LES JOKERS LÀ
            ArrayList<int[]> combos = plr.getDeck().scanCombos();
            // OU LÀ

            // AJOUTER LES POINTS ET TOUT, LÀ JE LE FAIT PAS HISTOIRE
            // DE POUVOIR TESTER AVANT 3H DU MAT

            for (Card c : plr.getDeck().getAllCards()) {
                this.discardPile.addCard(c);
            }
            plr.getDeck().clear();
        }


        // METTRE LE JOUEUR AVEC LE PLUS/MOINS DE POINTS EN 1ER

        for (Card c : this.discardPile.getAllCards()) {
            this.drawPile.addCard(c);
        }
        this.discardPile.clear();

        System.out.print("Draw pile: ");
        this.drawPile.printAll();
        System.out.print("Discard pile: ");
        this.discardPile.printAll();

        System.out.println("Shuffling draw pile...");
        drawPile.shuffle();
        System.out.print("New draw pile: ");
        this.drawPile.printAll();

        for (Player plr : this.players) {
            Deck deck = plr.getDeck();
            int height = deck.getMaxHeight();
            int length = deck.getMaxLength();
            for (int i=0;i<height;i++) {
                ArrayList<Card> row = new ArrayList<>();
                for (int j=0;j<length;j++) {
                    row.add(drawPile.pop());
                }
                deck.addRow(row);
            }
            System.out.println(plr.getName()+"'s deck:");
            deck.printAll();
        }

        beginRound();
    }

    public void beginGame() {
        prepareNewRound();
    }
}