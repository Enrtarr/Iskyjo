import java.util.ArrayList;
import java.util.Scanner;

import game.*;
// import jokers.*;
import game.actions.*;

public class App {
    public static void main(String[] args) throws Exception {
        int nbrOfCards = 150;
        int nbrOfPlayers = 1;

        Scanner scanner = new Scanner(System.in);

        GameController game = setupGame(nbrOfPlayers, nbrOfCards);
        int answer2 = scanner.nextInt();
        // FIND A WAY TO START THE GAME CLEANLY
        Action beginGame = new BeginGameAction();
        game.execute(beginGame);
        
        while (true) {
            Player curPlayer = game.getCurrentPlayer();

            System.out.println("Player "+curPlayer.getName()+"'s turn.");
            System.out.println("Here is you deck:");
            curPlayer.getDeck().printAll();
            System.out.println("Here are the top cards of both piles:");
            try {System.out.println("Draw pile: "+game.getDrawPileTop().getValue());}
            catch (IllegalStateException e) {System.out.println("Draw pile: empty");}
            
            try {System.out.println("Discard pile: "+game.getDiscardPileTop().getValue());}
            catch (IllegalStateException e) {System.out.println("Discard pile: empty");}

            System.out.println("What would you want to do?");
            System.out.println("1) Pick the card at the top of the draw pile");
            System.out.println("2) Pick the card at the top of the discard pile");

            int answer = scanner.nextInt();

            // if (scanner.hasNextInt()) {
            //     int answer = scanner.nextInt();
            //     switch (answer) {
            //         case 1:
            //             System.out.println("ok");
            //             break;
            //         case 2:
            //             System.out.println("arg");
            //             break;
            //     }
            // } else {
            //     System.out.println("No input available. Exiting.");
            //     break;
            // }

            // switch (answer) {
            //     case 1:
            //         System.out.println("ok");
            //         break;
            //     case 2:
            //         System.out.println("arg");
            //         break;
            //     default:
            // }
        }

        // scanner.close();

        // System.out.println("Generating a draw pile with " + nbrOfCards + " cards");
        // Pile drawPile = new Pile(nbrOfCards);
        // drawPile.printAll(true);

        // Scanner scanner = new Scanner(System.in);

        // System.out.print("Enter two integers separated by a space: ");

        // int a = scanner.nextInt();
        // int b = scanner.nextInt();
        // System.out.println("1st: "+a+" 2nd: "+b);
        // scanner.close();

        // GameController game = setupGame();
        // Scanner scanner = new Scanner(System.in);

        // while (!game.isGameOver()) {
        //     Player player = game.getCurrentPlayer();

        //     System.out.println("Your turn: " + player.getName());
        //     int choice = scanner.nextInt();

        //     game.playCard(player, player.getHand().get(choice));
        //     game.endTurn();
        // }
    }

    public static GameController setupGame(int nbrPlr, int nbrCard) {
        //Scanner scanner = new Scanner(System.in);

        ArrayList<Player> playerList = new ArrayList<>();

        for (int i=1;i<nbrPlr+1;i++) {
            // System.out.print("Please enter player "+i+"'s name: ");
            // String name = scanner.nextLine();
            // playerList.add(new Player(name));
            playerList.add(new Player());
        }

        //scanner.close();

        return new GameController(playerList, nbrCard);
    }
}
